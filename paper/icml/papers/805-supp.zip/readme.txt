The enclosed videos are confirmed playable with VLC player.

video1.mp4 shows the push recovery test and training set for constrained and variational GPS

video2.mp4 shows the uneven terrain test and training set for constrained GPS

video3.mp4 shows some additional tests of the push recovery policy learned by constrained GPS
